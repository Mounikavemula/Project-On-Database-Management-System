<?php 

include('../session.php'); 
$con = mysqli_connect('localhost','root','','tracerdata') or die("ERROR");
?>