
<style type="text/css">
</style>
<divclass="alert alert-danger" role="alert" >
		<strong>Warning!</strong> Access Denied
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
<?php include ('alert-script.php');?>