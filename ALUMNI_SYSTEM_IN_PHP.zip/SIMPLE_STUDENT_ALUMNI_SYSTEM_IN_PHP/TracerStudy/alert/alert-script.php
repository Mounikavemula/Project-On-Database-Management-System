<script type="text/javascript">
	window.setTimeout(function() {
    $(".alert").fadeTo('slow', 0).slideUp('slow', function(){
        $(this).remove(); 
        
    });
}, 1500);
</script>