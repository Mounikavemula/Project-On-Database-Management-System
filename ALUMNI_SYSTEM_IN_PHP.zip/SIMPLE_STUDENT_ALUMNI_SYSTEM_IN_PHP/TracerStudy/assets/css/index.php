<?php 
 echo "<script>alert('!!!');
      window.location='../../index.php';
    </script>";


?>